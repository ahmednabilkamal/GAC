const Colors = {
  grey: '#7E7E7E',
  black: '#404040',
  blackHeavy: '#191919',
  blackMoreHeavy: '#262628',
  red: '#EF3D42',
  white: '#ffffff',
  whiteLight: '#F8F8F8',
  greyLight: '#E9E9E9',
  brownLight: '#A39161',
  greyHeavy: '#707070',
  black2: '#4B4B4B',
  blue: '#0539B1',
};

export default Colors;
