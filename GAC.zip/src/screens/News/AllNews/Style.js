import {StyleSheet} from 'react-native';

const Style = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    flex: 1,
  },
});

export default Style;
