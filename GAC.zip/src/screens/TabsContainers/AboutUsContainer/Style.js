import {StyleSheet} from 'react-native';

const Style = StyleSheet.create({
  newsContainer: {
    flex: 1,
    backgroundColor: 'white',
  },
});

export default Style;
